# Date: 2023/3/8 上午9:41
from distutils.core import setup

'''
name 模块名称
version 版本号
description 描述
author 作者
py_modules 要发布的内容
'''
setup(name='modelTest', version='1.0', description='文件统计模块',
      author='lv', py_modules=['modelTest'])
